package app.conjure_dex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}