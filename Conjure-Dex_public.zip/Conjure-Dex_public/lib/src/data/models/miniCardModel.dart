class MiniCardModel {
  final int id;
  final String title;

  MiniCardModel({required this.id, required this.title});
}